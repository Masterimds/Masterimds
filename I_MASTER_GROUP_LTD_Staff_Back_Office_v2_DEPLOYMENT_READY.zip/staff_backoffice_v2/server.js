const express=require('express');
const path=require('path');
const fs=require('fs');
const bcrypt=require('bcryptjs');
const jwt=require('jsonwebtoken');
const cookieParser=require('cookie-parser');
const Database=require('better-sqlite3');

const app=express();
app.disable('x-powered-by');
app.set('trust proxy',1);
app.use(express.json({limit:'2mb'}));
app.use(cookieParser());

const DATA=process.env.DATA_DIR || path.join(__dirname,'data');
fs.mkdirSync(DATA,{recursive:true});
const dbPath=process.env.DB_PATH || path.join(DATA,'staff.sqlite');
const db=new Database(dbPath);
db.pragma('journal_mode=WAL');
db.pragma('foreign_keys=ON');

const JWT_SECRET=process.env.JWT_SECRET;
if(!JWT_SECRET || JWT_SECRET.length < 32){
  console.error('JWT_SECRET must be set and at least 32 characters long.');
  process.exit(1);
}
const ADMIN_EMAIL=process.env.ADMIN_EMAIL;
const ADMIN_PASSWORD=process.env.ADMIN_PASSWORD;
if(!ADMIN_EMAIL || !ADMIN_PASSWORD || ADMIN_PASSWORD.length < 12){
  console.error('ADMIN_EMAIL and ADMIN_PASSWORD are required; ADMIN_PASSWORD must be at least 12 characters.');
  process.exit(1);
}

// Schema

db.exec(`
CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY,email TEXT UNIQUE NOT NULL,password_hash TEXT NOT NULL,role TEXT NOT NULL,staff_id TEXT,created_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS staff(id INTEGER PRIMARY KEY,staff_id TEXT UNIQUE NOT NULL,name TEXT NOT NULL,position TEXT,department TEXT,phone TEXT,address TEXT,start_date TEXT,salary REAL DEFAULT 0,status TEXT DEFAULT 'Active',created_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS attendance(id INTEGER PRIMARY KEY,staff_id TEXT NOT NULL,date TEXT NOT NULL,clock_in TEXT,clock_out TEXT,status TEXT DEFAULT 'Present');
CREATE TABLE IF NOT EXISTS leave_requests(id INTEGER PRIMARY KEY,staff_id TEXT NOT NULL,type TEXT,start_date TEXT,end_date TEXT,reason TEXT,status TEXT DEFAULT 'Pending',created_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS payroll(id INTEGER PRIMARY KEY,staff_id TEXT NOT NULL,period TEXT NOT NULL,basic REAL DEFAULT 0,allowance REAL DEFAULT 0,deduction REAL DEFAULT 0,net REAL DEFAULT 0,created_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS announcements(id INTEGER PRIMARY KEY,title TEXT NOT NULL,message TEXT NOT NULL,created_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS tasks(id INTEGER PRIMARY KEY,title TEXT NOT NULL,description TEXT,staff_id TEXT,status TEXT DEFAULT 'Pending',due_date TEXT,created_at TEXT DEFAULT CURRENT_TIMESTAMP);
`);

// First deployment: create/update the configured administrator account and seed only Ibrahim.
const existingAdmin=db.prepare('SELECT * FROM users WHERE email=?').get(ADMIN_EMAIL);
const adminHash=bcrypt.hashSync(ADMIN_PASSWORD,12);
if(existingAdmin){
  db.prepare('UPDATE users SET password_hash=?,role=?,staff_id=? WHERE email=?').run(adminHash,'CEO','IMG-001',ADMIN_EMAIL);
}else{
  db.prepare('INSERT INTO users(email,password_hash,role,staff_id) VALUES(?,?,?,?)').run(ADMIN_EMAIL,adminHash,'CEO','IMG-001');
}
if(!db.prepare('SELECT 1 FROM staff WHERE staff_id=?').get('IMG-001')){
  db.prepare('INSERT INTO staff(staff_id,name,position,department,status) VALUES(?,?,?,?,?)').run('IMG-001','Ibrahim Ibrahim Hassan','Chief Executive Officer','Executive Management','Active');
}

function auth(req,res,next){
  try{
    const t=req.cookies.imaster_session;
    if(!t)return res.status(401).json({error:'Authentication required'});
    req.user=jwt.verify(t,JWT_SECRET);
    next();
  }catch(e){return res.status(401).json({error:'Invalid or expired session'});}
}
function roles(...r){return (req,res,next)=>r.includes(req.user.role)?next():res.status(403).json({error:'Access denied'});}

app.get('/healthz',(req,res)=>res.status(200).json({ok:true,service:'I. MASTER GROUP LTD Staff Back Office'}));

app.post('/api/login',(req,res)=>{
  const {email,password}=req.body||{};
  const u=db.prepare('SELECT * FROM users WHERE email=?').get(email||'');
  if(!u||!bcrypt.compareSync(password||'',u.password_hash))return res.status(401).json({error:'Invalid email or password'});
  const token=jwt.sign({id:u.id,email:u.email,role:u.role,staff_id:u.staff_id},JWT_SECRET,{expiresIn:'8h'});
  res.cookie('imaster_session',token,{httpOnly:true,sameSite:'lax',secure:true,maxAge:8*60*60*1000,path:'/'});
  res.json({user:{email:u.email,role:u.role,staff_id:u.staff_id}});
});
app.post('/api/logout',(req,res)=>{res.clearCookie('imaster_session',{httpOnly:true,sameSite:'lax',secure:true,path:'/'});res.json({ok:true});});
app.get('/api/me',auth,(req,res)=>res.json({user:req.user}));
app.get('/api/staff',auth,(req,res)=>res.json(db.prepare('SELECT * FROM staff ORDER BY id DESC').all()));
app.post('/api/staff',auth,roles('CEO','MD','HR'),(req,res)=>{const x=req.body;try{db.prepare('INSERT INTO staff(staff_id,name,position,department,phone,address,start_date,salary,status) VALUES(@staff_id,@name,@position,@department,@phone,@address,@start_date,@salary,@status)').run({...x,status:x.status||'Active',salary:Number(x.salary)||0});res.json({ok:true});}catch(e){res.status(400).json({error:e.message});}});
app.put('/api/staff/:id',auth,roles('CEO','MD','HR'),(req,res)=>{const x=req.body;db.prepare('UPDATE staff SET name=@name,position=@position,department=@department,phone=@phone,address=@address,start_date=@start_date,salary=@salary,status=@status WHERE id=@id').run({...x,id:req.params.id,salary:Number(x.salary)||0});res.json({ok:true});});
app.get('/api/attendance',auth,(req,res)=>res.json(db.prepare('SELECT * FROM attendance ORDER BY date DESC,id DESC').all()));
app.post('/api/attendance',auth,roles('CEO','MD','HR','IT Admin'),(req,res)=>{db.prepare('INSERT INTO attendance(staff_id,date,clock_in,clock_out,status) VALUES(?,?,?,?,?)').run(req.body.staff_id,req.body.date,req.body.clock_in||'',req.body.clock_out||'',req.body.status||'Present');res.json({ok:true});});
app.get('/api/leave',auth,(req,res)=>res.json(db.prepare('SELECT * FROM leave_requests ORDER BY id DESC').all()));
app.post('/api/leave',auth,(req,res)=>{const b=req.body;db.prepare('INSERT INTO leave_requests(staff_id,type,start_date,end_date,reason) VALUES(?,?,?,?,?)').run(b.staff_id||req.user.staff_id,b.type,b.start_date,b.end_date,b.reason);res.json({ok:true});});
app.put('/api/leave/:id',auth,roles('CEO','MD','HR'),(req,res)=>{db.prepare('UPDATE leave_requests SET status=? WHERE id=?').run(req.body.status,req.params.id);res.json({ok:true});});
app.get('/api/payroll',auth,roles('CEO','MD','Finance'),(req,res)=>res.json(db.prepare('SELECT * FROM payroll ORDER BY id DESC').all()));
app.post('/api/payroll',auth,roles('CEO','MD','Finance'),(req,res)=>{const b=req.body,net=Number(b.basic||0)+Number(b.allowance||0)-Number(b.deduction||0);db.prepare('INSERT INTO payroll(staff_id,period,basic,allowance,deduction,net) VALUES(?,?,?,?,?,?)').run(b.staff_id,b.period,Number(b.basic)||0,Number(b.allowance)||0,Number(b.deduction)||0,net);res.json({ok:true,net});});
app.get('/api/announcements',auth,(req,res)=>res.json(db.prepare('SELECT * FROM announcements ORDER BY id DESC').all()));
app.post('/api/announcements',auth,roles('CEO','MD','HR'),(req,res)=>{db.prepare('INSERT INTO announcements(title,message) VALUES(?,?)').run(req.body.title,req.body.message);res.json({ok:true});});
app.get('/api/tasks',auth,(req,res)=>res.json(db.prepare('SELECT * FROM tasks ORDER BY id DESC').all()));
app.post('/api/tasks',auth,roles('CEO','MD','HR','IT Admin'),(req,res)=>{const b=req.body;db.prepare('INSERT INTO tasks(title,description,staff_id,status,due_date) VALUES(?,?,?,?,?)').run(b.title,b.description,b.staff_id||'',b.status||'Pending',b.due_date||'');res.json({ok:true});});
app.get('/api/dashboard',auth,(req,res)=>{const count=db.prepare("SELECT COUNT(*) n FROM staff WHERE status='Active'").get().n;const pending=db.prepare("SELECT COUNT(*) n FROM leave_requests WHERE status='Pending'").get().n;const payroll=db.prepare('SELECT COALESCE(SUM(net),0) n FROM payroll').get().n;res.json({active_staff:count,pending_leave:pending,total_payroll:payroll});});

app.use(express.static(path.join(__dirname,'public')));
app.get('*',(req,res)=>res.sendFile(path.join(__dirname,'public','index.html')));

const port=Number(process.env.PORT)||3000;
app.listen(port,'0.0.0.0',()=>console.log(`Staff Back Office listening on port ${port}`));
