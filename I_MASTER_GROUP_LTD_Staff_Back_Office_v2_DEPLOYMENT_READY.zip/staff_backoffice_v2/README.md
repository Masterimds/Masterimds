# I. MASTER GROUP LTD — Staff Back Office v2 (Deployment Ready)

Production-oriented Express/SQLite starter for the internal staff administration portal.

## Included
- Node.js + Express backend
- SQLite database on configurable persistent storage
- bcrypt password hashing
- HTTP-only JWT session cookie
- Role checks: CEO, MD, HR, Finance, IT Admin, Sales, Staff
- Staff management
- Attendance
- Leave
- Payroll
- Announcements
- Tasks
- Dashboard
- `/healthz` health endpoint
- Render deployment blueprint with persistent disk

## Seeded account
Only Ibrahim Ibrahim Hassan / IMG-001 is seeded as staff.

For production, the administrator email and password come from environment variables:
- `ADMIN_EMAIL`
- `ADMIN_PASSWORD`

The app will refuse to start without a `JWT_SECRET` of at least 32 characters and an admin password of at least 12 characters.

## Local development
Create environment variables before starting:

```bash
JWT_SECRET="replace-with-a-long-random-secret-at-least-32-characters"
ADMIN_EMAIL="your-admin-email@example.com"
ADMIN_PASSWORD="your-strong-admin-password"
npm install
npm start
```

Then open `http://localhost:3000`.

## Deployment
See `DEPLOY_RENDER.md`.
