I. MASTER GROUP LTD — Staff Back Office
=============================================

This is a working browser-based starter application.

Demo administrator:
Email: admin@imastergroup.local
Password: ChangeMe123!

IMPORTANT:
- This version uses localStorage for data persistence in the browser.
- It is NOT production-secure authentication.
- Only Ibrahim Ibrahim Hassan / IMG-001 is preloaded.
- Other staff are added through Staff Management.
- Before production, replace demo authentication with a server/database, hash passwords,
  add role-based access, HTTPS, audit logs, backups, secure document storage and validation.

Files:
index.html
style.css
app.js

Run:
Open index.html in a modern browser.

For production:
Use a backend such as Node.js/Express, PHP/Laravel, or another server framework,
with MySQL/PostgreSQL and secure session/JWT authentication.
