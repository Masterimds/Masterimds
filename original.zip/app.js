const DBKEY="imaster_staff_backoffice_v1";
const ADMIN={email:"admin@imastergroup.local",password:"ChangeMe123!"};
let db=JSON.parse(localStorage.getItem(DBKEY)||"null")||{
 staff:[{id:"IMG-001",name:"Ibrahim Ibrahim Hassan",position:"Chief Executive Officer",department:"Executive Management",phone:"07070335573",address:"Kano State, Nigeria",start:"",status:"Active"}],
 attendance:[],leave:[],payroll:[],documents:[],announcements:[],tasks:[]
};
const save=()=>localStorage.setItem(DBKEY,JSON.stringify(db));
const $=s=>document.querySelector(s);
const esc=s=>String(s??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
const money=n=>"₦"+Number(n||0).toLocaleString("en-NG",{minimumFractionDigits:2});
const today=()=>new Date().toLocaleDateString("en-NG",{weekday:"long",year:"numeric",month:"long",day:"numeric"});
$("#today").textContent=today();

$("#loginForm").addEventListener("submit",e=>{
 e.preventDefault();
 if($("#email").value.trim()===ADMIN.email && $("#password").value===ADMIN.password){
   sessionStorage.setItem("imaster_auth","1"); $("#login").classList.add("hidden");$("#app").classList.remove("hidden");route("dashboard");
 }else alert("Invalid demo credentials.");
});
$("#logout").onclick=()=>{sessionStorage.removeItem("imaster_auth");location.reload()};
if(sessionStorage.getItem("imaster_auth")){$("#login").classList.add("hidden");$("#app").classList.remove("hidden");route("dashboard")}

document.querySelectorAll("#nav button").forEach(b=>b.onclick=()=>route(b.dataset.page));
function route(page){
 document.querySelectorAll("#nav button").forEach(b=>b.classList.toggle("active",b.dataset.page===page));
 $("#pageTitle").textContent=page.replace(/(^|_)/g," ").replace(/\b\w/g,x=>x.toUpperCase());
 pages[page]();
}
function shell(title,body,actions=""){return `<div class="section-head"><div><h3>${title}</h3></div><div class="toolbar">${actions}</div></div>${body}`}
const pages={
 dashboard(){
  const active=db.staff.filter(s=>s.status==="Active").length;
  $("#content").innerHTML=`<div class="grid cards">
   <div class="card"><div class="label">Active Staff</div><div class="stat">${active}</div></div>
   <div class="card"><div class="label">Attendance Records</div><div class="stat">${db.attendance.length}</div></div>
   <div class="card"><div class="label">Pending Leave</div><div class="stat">${db.leave.filter(x=>x.status==="Pending").length}</div></div>
   <div class="card"><div class="label">Payroll Records</div><div class="stat">${db.payroll.length}</div></div>
  </div>
  <div class="section grid" style="grid-template-columns:2fr 1fr">
   <div class="card"><h3>Welcome, Ibrahim</h3><p class="muted">This is the administrative Staff Back Office for I. MASTER GROUP LTD.</p><div class="notice">Only <b>Ibrahim Ibrahim Hassan (IMG-001)</b> is preloaded. Add other staff from Staff Management.</div></div>
   <div class="card"><h3>Company</h3><p class="muted">Kano State, Nigeria<br>07070335573<br>imasterdigitalservices@gmail.com</p></div>
  </div>`;
 },
 staff(){
  $("#content").innerHTML=shell("Staff Management",`<div class="toolbar"><input id="staffSearch" placeholder="Search staff..."><button class="btn primary" id="addStaff">+ Add Staff</button></div><div class="section"><table><thead><tr><th>Staff ID</th><th>Name</th><th>Position</th><th>Department</th><th>Phone</th><th>Status</th><th></th></tr></thead><tbody id="staffRows"></tbody></table></div>`);
  const render=()=>{
   const q=$("#staffSearch").value.toLowerCase();$("#staffRows").innerHTML=db.staff.filter(s=>(s.name+" "+s.id+" "+s.department+" "+s.position).toLowerCase().includes(q)).map(s=>`<tr><td>${esc(s.id)}</td><td><b>${esc(s.name)}</b></td><td>${esc(s.position)}</td><td>${esc(s.department)}</td><td>${esc(s.phone)}</td><td>${esc(s.status)}</td><td><button class="btn danger" data-del="${esc(s.id)}">Delete</button></td></tr>`).join("")||`<tr><td colspan="7" class="empty">No staff found.</td></tr>`;
   document.querySelectorAll("[data-del]").forEach(b=>b.onclick=()=>{if(b.dataset.del==="IMG-001")return alert("The administrator record cannot be deleted.");if(confirm("Delete this staff record?")){db.staff=db.staff.filter(x=>x.id!==b.dataset.del);save();render()}});
  };render();$("#staffSearch").oninput=render;
  $("#addStaff").onclick=()=>showForm("Add Staff",[
   ["id","Staff ID","text"],["name","Full Name","text"],["position","Position","text"],["department","Department","text"],["phone","Phone","text"],["address","Address","text"],["start","Start Date","date"]
  ],v=>{if(db.staff.some(s=>s.id===v.id))return alert("Staff ID already exists.");db.staff.push({...v,status:"Active"});save();pages.staff()});
 },
 attendance(){
  $("#content").innerHTML=shell("Attendance",`<button class="btn primary" id="recordAttendance">+ Record Attendance</button><div class="section"><table><thead><tr><th>Date</th><th>Staff ID</th><th>Status</th><th>Clock In</th><th>Clock Out</th></tr></thead><tbody>${db.attendance.map(x=>`<tr><td>${esc(x.date)}</td><td>${esc(x.staff)}</td><td>${esc(x.status)}</td><td>${esc(x.in)}</td><td>${esc(x.out)}</td></tr>`).join("")||`<tr><td colspan="5" class="empty">No attendance records.</td></tr>`}</tbody></table></div>`);
  $("#recordAttendance").onclick=()=>showForm("Record Attendance",[["date","Date","date"],["staff","Staff ID","text"],["status","Status","text"],["in","Clock In","time"],["out","Clock Out","time"]],v=>{db.attendance.push(v);save();pages.attendance()});
 },
 leave(){
  $("#content").innerHTML=shell("Leave Management",`<button class="btn primary" id="newLeave">+ Add Leave Request</button><div class="section"><table><thead><tr><th>Staff</th><th>Type</th><th>From</th><th>To</th><th>Reason</th><th>Status</th><th>Action</th></tr></thead><tbody id="leaveRows">${db.leave.map((x,i)=>`<tr><td>${esc(x.staff)}</td><td>${esc(x.type)}</td><td>${esc(x.from)}</td><td>${esc(x.to)}</td><td>${esc(x.reason)}</td><td>${esc(x.status)}</td><td>${x.status==="Pending"?`<button class="btn" data-approve="${i}">Approve</button> <button class="btn danger" data-reject="${i}">Reject</button>`:"—"}</td></tr>`).join("")||`<tr><td colspan="7" class="empty">No leave requests.</td></tr>`}</tbody></table></div>`);
  $("#newLeave").onclick=()=>showForm("Leave Request",[["staff","Staff ID","text"],["type","Leave Type","text"],["from","From","date"],["to","To","date"],["reason","Reason","textarea"]],v=>{db.leave.push({...v,status:"Pending"});save();pages.leave()});
  document.querySelectorAll("[data-approve]").forEach(b=>b.onclick=()=>{db.leave[b.dataset.approve].status="Approved";save();pages.leave()});
  document.querySelectorAll("[data-reject]").forEach(b=>b.onclick=()=>{db.leave[b.dataset.reject].status="Rejected";save();pages.leave()});
 },
 payroll(){
  $("#content").innerHTML=shell("Payroll & Payslips",`<button class="btn primary" id="newPayroll">+ Add Payroll Record</button><div class="section"><table><thead><tr><th>Period</th><th>Staff ID</th><th>Basic</th><th>Allowance</th><th>Deduction</th><th>Net Pay</th><th></th></tr></thead><tbody>${db.payroll.map((x,i)=>`<tr><td>${esc(x.period)}</td><td>${esc(x.staff)}</td><td>${money(x.basic)}</td><td>${money(x.allowance)}</td><td>${money(x.deduction)}</td><td><b>${money(Number(x.basic)+Number(x.allowance)-Number(x.deduction))}</b></td><td><button class="btn" data-slip="${i}">View Payslip</button></td></tr>`).join("")||`<tr><td colspan="7" class="empty">No payroll records.</td></tr>`}</tbody></table></div>`);
  $("#newPayroll").onclick=()=>showForm("Payroll Record",[["period","Pay Period","text"],["staff","Staff ID","text"],["basic","Basic Salary","number"],["allowance","Allowances","number"],["deduction","Deductions","number"]],v=>{db.payroll.push(v);save();pages.payroll()});
  document.querySelectorAll("[data-slip]").forEach(b=>b.onclick=()=>{const x=db.payroll[b.dataset.slip],s=db.staff.find(z=>z.id===x.staff)||{};const net=Number(x.basic)+Number(x.allowance)-Number(x.deduction);const w=window.open("","_blank");w.document.write(`<html><head><title>Payslip</title><style>body{font-family:Arial;padding:40px}h1{color:#071a35}.box{border:1px solid #ddd;padding:25px;max-width:650px}table{width:100%;border-collapse:collapse}td{padding:10px;border-bottom:1px solid #ddd}.net{font-size:24px;font-weight:bold}</style></head><body><div class="box"><h1>I. MASTER GROUP LTD</h1><p>PAYSLIP — ${esc(x.period)}</p><p><b>${esc(s.name||x.staff)}</b><br>${esc(s.position||"")} · ${esc(x.staff)}</p><table><tr><td>Basic Salary</td><td>${money(x.basic)}</td></tr><tr><td>Allowances</td><td>${money(x.allowance)}</td></tr><tr><td>Deductions</td><td>${money(x.deduction)}</td></tr><tr><td class="net">NET PAY</td><td class="net">${money(net)}</td></tr></table><br><button onclick="print()">Print / Save PDF</button></div></body></html>`);w.document.close()});
 },
 documents(){
  $("#content").innerHTML=shell("Documents",`<button class="btn primary" id="newDoc">+ Add Document</button><div class="section"><table><thead><tr><th>Title</th><th>Type</th><th>Staff ID</th><th>Date</th><th>Notes</th></tr></thead><tbody>${db.documents.map(x=>`<tr><td>${esc(x.title)}</td><td>${esc(x.type)}</td><td>${esc(x.staff)}</td><td>${esc(x.date)}</td><td>${esc(x.notes)}</td></tr>`).join("")||`<tr><td colspan="5" class="empty">No documents.</td></tr>`}</tbody></table></div>`);
  $("#newDoc").onclick=()=>showForm("Add Document",[["title","Document Title","text"],["type","Document Type","text"],["staff","Staff ID","text"],["date","Date","date"],["notes","Notes","textarea"]],v=>{db.documents.push(v);save();pages.documents()});
 },
 announcements(){
  $("#content").innerHTML=shell("Announcements",`<button class="btn primary" id="newAnn">+ New Announcement</button><div class="section">${db.announcements.map(x=>`<div class="card" style="margin-bottom:12px"><h3>${esc(x.title)}</h3><p>${esc(x.body)}</p><small class="muted">${esc(x.date)}</small></div>`).join("")||`<div class="empty">No announcements.</div>`}</div>`);
  $("#newAnn").onclick=()=>showForm("Announcement",[["title","Title","text"],["body","Message","textarea"],["date","Date","date"]],v=>{db.announcements.unshift(v);save();pages.announcements()});
 },
 tasks(){
  $("#content").innerHTML=shell("Tasks",`<button class="btn primary" id="newTask">+ Add Task</button><div class="section"><table><thead><tr><th>Task</th><th>Assigned To</th><th>Due</th><th>Status</th></tr></thead><tbody>${db.tasks.map((x,i)=>`<tr><td>${esc(x.title)}</td><td>${esc(x.staff)}</td><td>${esc(x.due)}</td><td><select data-task="${i}"><option ${x.status==="Pending"?"selected":""}>Pending</option><option ${x.status==="In Progress"?"selected":""}>In Progress</option><option ${x.status==="Completed"?"selected":""}>Completed</option></select></td></tr>`).join("")||`<tr><td colspan="4" class="empty">No tasks.</td></tr>`}</tbody></table></div>`);
  $("#newTask").onclick=()=>showForm("Add Task",[["title","Task","text"],["staff","Assigned Staff ID","text"],["due","Due Date","date"]],v=>{db.tasks.push({...v,status:"Pending"});save();pages.tasks()});
  document.querySelectorAll("[data-task]").forEach(s=>s.onchange=()=>{db.tasks[s.dataset.task].status=s.value;save()});
 },
 reports(){
  const payroll=db.payroll.reduce((a,x)=>a+Number(x.basic)+Number(x.allowance)-Number(x.deduction),0);
  $("#content").innerHTML=shell("Reports",`<div class="grid cards"><div class="card"><div class="label">Staff</div><div class="stat">${db.staff.length}</div></div><div class="card"><div class="label">Payroll Total</div><div class="stat">${money(payroll)}</div></div><div class="card"><div class="label">Leave Requests</div><div class="stat">${db.leave.length}</div></div><div class="card"><div class="label">Documents</div><div class="stat">${db.documents.length}</div></div></div><div class="section card"><h3>Operational Summary</h3><p class="muted">Use the modules to maintain current staff, attendance, leave, payroll and document records. This report is generated from browser storage in this code version.</p></div>`);
 },
 settings(){
  $("#content").innerHTML=shell("Settings",`<div class="card"><h3>Administrator</h3><p><b>Ibrahim Ibrahim Hassan</b><br>CEO · Administrator<br>IMG-001</p><button class="btn danger" id="reset">Reset Demo Data</button></div><div class="section card"><h3>Production checklist</h3><ul><li>Replace demo login with server-side authentication.</li><li>Use a real database such as MySQL/PostgreSQL.</li><li>Hash passwords and enable HTTPS.</li><li>Add role-based permissions and audit logs.</li><li>Store documents outside the public web root.</li><li>Configure backups and recovery.</li></ul></div>`);
  $("#reset").onclick=()=>{if(confirm("Reset all local demo data?")){localStorage.removeItem(DBKEY);location.reload()}};
 }
};
function showForm(title,fields,submit){
 const overlay=document.createElement("div");overlay.className="login-wrap";overlay.style.position="fixed";overlay.style.zIndex=20;overlay.innerHTML=`<div class="login-card" style="max-width:650px"><h2>${title}</h2><form class="form" id="modalForm"><div class="form-grid">${fields.map(([k,l,t])=>`<label>${l}<${t==="textarea"?"textarea":`input type="${t}"`} name="${k}" required></${t==="textarea"?"textarea":"input"}></label>`).join("")}</div><div class="form-actions"><button type="button" class="btn" id="cancel">Cancel</button><button class="btn primary" type="submit">Save</button></div></form></div>`;
 document.body.appendChild(overlay);$("#cancel").onclick=()=>overlay.remove();$("#modalForm").onsubmit=e=>{e.preventDefault();const v=Object.fromEntries(new FormData(e.target));submit(v);overlay.remove()};
}
