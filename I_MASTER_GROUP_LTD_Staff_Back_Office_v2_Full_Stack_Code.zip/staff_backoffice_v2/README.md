# I. MASTER GROUP LTD — Staff Back Office v2

A full-stack starter built from the previous browser prototype.

## Includes
- Express backend
- SQLite database
- Secure password hashing with bcryptjs
- HTTP-only signed session cookie using JWT
- Role checks (CEO, MD, HR, Finance, IT Admin, Sales, Staff)
- Staff management
- Attendance
- Leave requests and approval
- Payroll calculation
- Announcements
- Tasks
- Dashboard

## First login
Email: admin@imastergroup.local
Password: ChangeMe123!

Only Ibrahim Ibrahim Hassan / IMG-001 is seeded.

## Run locally
1. Install Node.js 18+.
2. Open this folder in a terminal.
3. Run `npm install`.
4. Set `JWT_SECRET` to a long random value.
5. Run `npm start`.
6. Open http://localhost:3000

## Production checklist
Change the demo password, use a strong secret, HTTPS, database backups, secure hosting, audit logging, CSRF protection, rate limiting, file/document storage controls and a production database strategy before real HR data is entered.
